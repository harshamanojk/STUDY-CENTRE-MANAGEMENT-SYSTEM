<?php
// In production, hide errors from output
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

header('Content-Type: application/json');
$response = ['status' => 'error', 'message' => 'Unknown error occurred'];

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    $response['message'] = 'Invalid request method.';
    echo json_encode($response);
    exit;
}

// Get POST inputs
$fullname        = trim($_POST['fullname'] ?? '');
$contact_number  = trim($_POST['contact_number'] ?? '');
$email_id        = trim($_POST['email_id'] ?? '');
$subject         = trim($_POST['subject'] ?? '');

// Validate inputs
if (empty($fullname) || empty($contact_number) || empty($email_id) || empty($subject)) {
    http_response_code(400);
    $response['message'] = 'Please fill in all fields.';
    echo json_encode($response);
    exit;
}

if (!filter_var($email_id, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    $response['message'] = 'Invalid email format.';
    echo json_encode($response);
    exit;
}

if (strlen($fullname) > 100) {
    http_response_code(400);
    $response['message'] = 'Full Name must be 100 characters or less.';
    echo json_encode($response);
    exit;
}

if (strlen($contact_number) > 20) {
    http_response_code(400);
    $response['message'] = 'Contact Number must be 20 characters or less.';
    echo json_encode($response);
    exit;
}

if (strlen($subject) > 220) {
    http_response_code(400);
    $response['message'] = 'Subject must be 220 characters or less.';
    echo json_encode($response);
    exit;
}

// DB connection
$conn = new mysqli("localhost", "root", "", "eduaxis");

if ($conn->connect_error) {
    http_response_code(500);
    $response['message'] = 'Database connection failed.';
    echo json_encode($response);
    exit;
}

$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("INSERT INTO contact_form (fullname, contact_number, email_id, subject) VALUES (?, ?, ?, ?)");

if (!$stmt) {
    http_response_code(500);
    $response['message'] = 'Database prepare failed.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param("ssss", $fullname, $contact_number, $email_id, $subject);

if ($stmt->execute()) {
    $response['status'] = 'success';
    $response['message'] = 'Thank you! Your suggestion has been submitted.';
} else {
    http_response_code(500);
    $response['message'] = 'Failed to save your suggestion.';
}

$stmt->close();
$conn->close();

echo json_encode($response);
exit;
